
# coding: utf-8

# In[177]:

import sys
import numpy as np
import scipy.stats as ss
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

primary_results = 'primary_results.csv'
county_facts = 'county_facts.csv'
print("loading %s" % primary_results)
primaryResultDF = pd.read_csv(primary_results,sep=',',low_memory=False)
print("loading %s" % county_facts)
countyFactsDF = pd.read_csv(county_facts,sep=',',low_memory=False)




# In[178]:

#remove the state rows
countyFactsDF = countyFactsDF[countyFactsDF['state_abbreviation']!= ""]


# In[180]:

def concatCountyFactsWithPrimaryResult(countyDF, primaryDF, name):
    primaryDataForName = primaryDF[primaryDF.candidate == name]
    countyDF = countyDF[countyDF['fips'].isin(primaryDataForName['fips'])]
    frames = [primaryDataForName,countyDF]
    result = pd.merge(primaryDataForName, countyDF, on=['fips', 'fips'])
    result.drop(['state','county','fips','party','candidate','fraction_votes','area_name','state_abbreviation_x','state_abbreviation_y'],inplace=True,axis=1)
    return result
    
def getCandidateDF(name):
    return concatCountyFactsWithPrimaryResult(countyFactsDF, primaryResultDF, name)

def getMatrix(name):
    list1= []
    result = getCandidateDF(name)
    result = result.reindex(np.random.permutation(result.index))
    y = result['votes']  
    result.drop(['votes'],inplace=True,axis=1)
    list1.append(result)
    list1.append(y)
    return list1



    


# In[182]:



# In[ ]:




# In[ ]:




# In[ ]:



